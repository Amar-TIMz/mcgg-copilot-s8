# MCGG Live Co-Pilot S8 (Offline PWA + Android APK)

## 1. Pasang di Komputer (Windows / Mac) & Telefon Melalui GitHub Pages
1. Muat naik semua fail dalam repositori ini ke GitHub.
2. Buka **Settings > Pages** di repositori GitHub anda.
3. Pada bahagian **Build and deployment > Source**, pilih **Deploy from a branch**, pilih branch **`main`** dan folder **`/(root)`**, kemudian tekan **Save**.
4. Buka pautan GitHub Pages anda di Chrome / Edge (PC atau telefon) dan tekan butang **Install App** (atau *Add to Home Screen*). Aplikasi akan terpasang dan berjalan **100% offline**.

## 2. Muat Turun `.APK` Android Secara Automatik
1. Buka tab **Actions** di repositori GitHub ini.
2. Pilih workflow **Build Android APK** yang selesai dijalankan dan muat turun artifak **`MCGG-Live-CoPilot-S8-APK`** (`app-debug.apk`).
